package student;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author karlj
 */
class Student {
    private int studentId;
    private String studentName;
    private int studentAge;
    private String studentEmail;
    private String studentCourse;

    // Constructor
    public Student(int studentId, String studentName, int studentAge, String studentEmail, String studentCourse) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.studentAge = studentAge;
        this.studentEmail = studentEmail;
        this.studentCourse = studentCourse;
    }

    // Getters and setters 

    public void saveStudent(ArrayList<Student> studentList) {
        studentList.add(this);
        System.out.println("Student details have been successfully saved.");
    }

    public static void searchStudent(ArrayList<Student> studentList, int searchId) {
        for (Student student : studentList) {
            if (student.studentId == searchId) {
                displayStudentDetails(student);
                return;
            }
        }
        System.out.println("Student with Student Id: " + searchId + " was not found!");
    }

    public static void deleteStudent(ArrayList<Student> studentList, int deleteId) {
        for (int i = 0; i < studentList.size(); i++) {
            if (studentList.get(i).studentId == deleteId) {
                studentList.remove(i);
                System.out.println("Student with Student Id: " + deleteId + " was deleted!");
                return;
            }
        }
        System.out.println("Student with Student Id: " + deleteId + " was not found!");
    }

    public static void studentReport(ArrayList<Student> studentList) {
        int studentCount = 0;
        for (Student student : studentList) {
            studentCount++;
            System.out.println("Student " + studentCount);
            displayStudentDetails(student);
        }
    }

    private static void displayStudentDetails(Student student) {
        System.out.println("-------------------------------------------------------");
        System.out.println("STUDENT ID : " + student.studentId);
        System.out.println("STUDENT NAME : " + student.studentName);
        System.out.println("STUDENT AGE : " + student.studentAge);
        System.out.println("STUDENT EMAIL : " + student.studentEmail);
        System.out.println("STUDENT COURSE : " + student.studentCourse);
    }
}

public class StudentManagementApp {
    public static void main(String[] args) {
        ArrayList<Student> studentList = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("CAPTURE A NEW STUDENT");
            System.out.println("***************************");
            System.out.print("Enter the student id: ");
            int studentId = scanner.nextInt();
            scanner.nextLine(); 
            System.out.print("Enter the student name: ");
            String studentName = scanner.nextLine();
            System.out.print("Enter the student age: ");
            int studentAge;
            while (true) {
                try {
                    studentAge = Integer.parseInt(scanner.nextLine());
                    if (studentAge >= 16) {
                        break;
                    } else {
                        System.out.println("You have entered an incorrect student age!!!");
                        System.out.print("Please re-enter the student age: ");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("You have entered an incorrect student age!!!");
                    System.out.print("Please re-enter the student age: ");
                }
            }
            System.out.print("Enter the student email: ");
            String studentEmail = scanner.nextLine();
            System.out.print("Enter the student course: ");
            String studentCourse = scanner.nextLine();

            Student newStudent = new Student(studentId, studentName, studentAge, studentEmail, studentCourse);
            newStudent.saveStudent(studentList);

            System.out.println("Enter (1) to launch menu or any other key to exit");
            String choice = scanner.nextLine();
            if (!choice.equals("1")) {
                break;
            }
        }

        while (true) {
            System.out.println("Menu:");
            System.out.println("1. Search for a student");
            System.out.println("2. Delete a student");
            System.out.println("3. View student report");
            System.out.println("4. Exit");

            System.out.print("Enter your choice: ");
            int menuChoice = scanner.nextInt();
            scanner.nextLine(); 

            switch (menuChoice) {
                case 1:
                    System.out.print("Enter the student id to search: ");
                    int searchId = scanner.nextInt();
                    scanner.nextLine(); 
                    Student.searchStudent(studentList, searchId);
                    break;
                case 2:
                    System.out.print("Enter the student id to delete: ");
                    int deleteId = scanner.nextInt();
                    scanner.nextLine(); 
                    System.out.print("Are you sure you want to delete Student " + deleteId + " from the system? (y/n): ");
                    String deleteChoice = scanner.nextLine();
                    if (deleteChoice.equalsIgnoreCase("y")) {
                        Student.deleteStudent(studentList, deleteId);
                    }
                    break;
                case 3:
                    Student.studentReport(studentList);
                    break;
                case 4:
                    System.out.println("Exiting the application.");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please select a valid option.");
            }
        }
    }
}
