package student;
import org.junit.Test;
import java.util.ArrayList;
/**
 *
 *@author karlj
 */
public class StudentTest {
        @Test
    public void testSaveStudent() {
        ArrayList<Student> studentList = new ArrayList<>();
        Student student = new Student(10111, "J.Bloggs", 19, "jbloggs@ymail.com", "disd");
        student.saveStudent(studentList);
        
    }
        @Test
    public void testSearchStudent() {
        ArrayList<Student> studentList = new ArrayList<>();
        Student student = new Student(10111, "J.Bloggs", 19, "jbloggs@ymail.com", "disd");
        studentList.add(student);
        
    }
        @Test
    public void testSearchStudent_StudentNotFound() {
        ArrayList<Student> studentList = new ArrayList<>();
        
    }
        @Test
    public void testDeleteStudent() {
        ArrayList<Student> studentList = new ArrayList<>();
        Student student = new Student(10111, "J.Bloggs", 19, "jbloggs@ymail.com", "disd");
        studentList.add(student);
        
    }
}
