package propertysalescommission;
import java.util.Arrays;

/**
 *
 * @author karlj
 */
public class PropertySalesCommission {
    public static void main(String[] args) {
        // Create a two-dimensional array to store the property sales
        double[][] propertySales = {{800000, 1500000, 2000000}, {700000, 1200000, 1600000}};

        // Calculate the total property sales for each estate agent
        double[] totalPropertySales = new double[2];
        for (int i = 0; i < propertySales.length; i++) {
            for (int j = 0; j < propertySales[i].length; j++) {
                totalPropertySales[i] += propertySales[i][j];
            }
        }

        // Calculate the total 2% commission earned by each estate agent
        double[] commissionEarned = new double[2];
        for (int i = 0; i < commissionEarned.length; i++) {
            commissionEarned[i] = totalPropertySales[i] * 0.02;
        }

        // Display the total property sales and commission earned for each estate agent
        System.out.println("Estate agent\tTotal property sales\tCommission earned");
        for (int i = 0; i < totalPropertySales.length; i++) {
            System.out.println(i + "\t\t\t\t\t\t" + totalPropertySales[i] + "\t\t\t\t" + commissionEarned[i]);
        }

        // Display the top-selling estate agent
        int topSellingAgentIndex = 0;
        for (int i = 1; i < totalPropertySales.length; i++) {
            if (totalPropertySales[i] > totalPropertySales[topSellingAgentIndex]) {
                topSellingAgentIndex = i;
            }
        }

        System.out.println("\nThe top-selling estate agent is estate agent " + topSellingAgentIndex);
    }
}

interface IEstateAgent {
    double EstateAgentSales(double[] propertySales);
    double EstateAgentCommission(double propertySales);
    int TopEstateAgent(double[] totalSales);
}

class EstateAgent implements IEstateAgent {

    @Override
    public double EstateAgentSales(double[] propertySales) {
        double totalSales = 0;
        for (double sales : propertySales) {
            totalSales += sales;
        }
        return totalSales;
    }

    @Override
    public double EstateAgentCommission(double propertySales) {
        return propertySales * 0.02;
    }

    @Override
    public int TopEstateAgent(double[] totalSales) {
        int topSellingAgentIndex = 0;
        for (int i = 1; i < totalSales.length; i++) {
            if (totalSales[i] > totalSales[topSellingAgentIndex]) {
                topSellingAgentIndex = i;
            }
        }
        return topSellingAgentIndex;
    }

    public static void main(String[] args) {
        // Create a two-dimensional array to store the property sales
        double[][] propertySales = {{800000, 1500000, 2000000}, {700000, 1200000, 1600000}};

        EstateAgent estateAgent = new EstateAgent();

        // Calculate the total property sales for each estate agent
        double[] totalPropertySales = new double[propertySales.length];
        for (int i = 0; i < propertySales.length; i++) {
            totalPropertySales[i] = estateAgent.EstateAgentSales(propertySales[i]);
        }

        // Calculate the total 2% commission earned by each estate agent
        double[] commissionEarned = new double[totalPropertySales.length];
        for (int i = 0; i < totalPropertySales.length; i++) {
            commissionEarned[i] = estateAgent.EstateAgentCommission(totalPropertySales[i]);
        }

        // Display the total property sales and commission earned for each estate agent
        System.out.println("Estate agent\tTotal property sales\tCommission earned");
        for (int i = 0; i < totalPropertySales.length; i++) {
            System.out.println(i + "\t\t\t\t\t\t" + totalPropertySales[i] + "\t\t\t\t" + commissionEarned[i]);
        }

        // Display the top-selling estate agent
        int topSellingAgentIndex = estateAgent.TopEstateAgent(totalPropertySales);
        System.out.println("\nThe top-selling estate agent is estate agent " + topSellingAgentIndex);
    }
}
