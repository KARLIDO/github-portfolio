import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class EstateAgentTest {

    @Test
    public void CalculateTotalSales_ReturnsTotalSales() {
        EstateAgent estateAgent = new EstateAgent();
        double[] propertySales = { 800000, 1500000, 2000000 };

        double totalSales = estateAgent.EstateAgentSales(propertySales);

        assertEquals(4300000, totalSales, 0.001); // Adjust the delta value based on precision requirements
    }

    @Test
    public void CalculateTotalCommission_ReturnsCommission() {
        EstateAgent estateAgent = new EstateAgent();
        double totalSales = 4300000;

        double commission = estateAgent.EstateAgentCommission(totalSales);

        assertEquals(86000, commission, 0.001); // Adjust the delta value based on precision requirements
    }

    @Test
    public void TopAgent_ReturnsTopPosition() {
        EstateAgent estateAgent = new EstateAgent();
        double[] totalSales = { 4300000, 2800000 };

        int topAgentPosition = estateAgent.TopEstateAgent(totalSales);

        assertEquals(0, topAgentPosition);
    }
}
