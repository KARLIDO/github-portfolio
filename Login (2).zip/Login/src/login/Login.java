package login;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;
import org.junit.Assertions;
import org.junit.Test;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Karl Jage ST10088984
 */


public class Login {
    String username;
    String password;
    String firstName;
    String lastName;

    public Login(String username, String password, String firstName, String lastName){
        this.username=username;
        this.password=password;
        this.firstName=firstName;
        this.lastName=lastName;
        
    }
    public static void main(String[] args) {
       Scanner scanner=new //Java Scanner Class - Oracle (https://docs.oracle.com/en/java/javase/11/docs/api/java.base/java/util/Scanner.html)
    Scanner(System.in);
       
       System.out.print("Enter username:");
       String username =scanner.nextLine();
       
       System.out.print("Enter password:");
       String password=scanner.nextLine();
       
       System.out.print("Enter first name:");
       String firstName=scanner.nextLine();
       
       System.out.print("Enter last name:");
       String lastName=scanner.nextLine();
       
       Login login=new Login(username, password, firstName, lastName);
       
       String registerMsg=login.registerUser();
       System.out.print(registerMsg);
       
       boolean loginSuccess=login.loginUser();
       String loginMsg=login.returnLoginStatus(loginSuccess);
       System.out.print(login);
       if (loginSuccess) {
            JOptionPane.showMessageDialog(null, "Welcome to EasyKanban!");

            int choice;
            do {
                System.out.println("Menu:");
                System.out.println("1) Add tasks");
                System.out.println("2) Show report");
                System.out.println("3) Quit");
                System.out.print("Enter your choice: ");
                choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline character

                switch (choice) {
                    case 1:
                        login.addTasks();
                        break;
                    case 2:
                        JOptionPane.showMessageDialog(null, "Coming Soon");
                        break;
                    case 3:
                        System.out.println("Exiting the application...");
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } while (choice != 3);
        } else {
            JOptionPane.showMessageDialog(null, "Username or password incorrect. Please try again.");
        }


       
    }
    public boolean loginUser() {
        String savedUsername = "example_username";
        String savedPassword = "Example1!";

        return username.equals(savedUsername) && password.equals(savedPassword);
    }

    public void addTasks() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of tasks: ");
        int numTasks = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        for (int i = 0; i < numTasks; i++) {
            System.out.println("\nTask " + (i + 1) + ":");
            System.out.print("Task Name: ");
            String taskName = scanner.nextLine();

            System.out.print("Task Description: ");
            String taskDescription = scanner.nextLine();
            if (taskDescription.length() > 50) {
                JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters");
                continue;
            }
//JOptionPane Documentation - Oracle (https://docs.oracle.com/en/java/javase/11/docs/api/java.desktop/javax/swing/JOptionPane.html)
            System.out.print("Developer First Name: ");
            String devFirstName = scanner.nextLine();

            System.out.print("Developer Last Name: ");
            String devLastName = scanner.nextLine();

            System.out.print("Task Duration (in hours): ");
            int taskDuration = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            String taskID = generateTaskID(taskName, i, devLastName);

            System.out.println("\nTask Details:");
            System.out.println("Task Status: To Do");
            System.out.println("Developer Details: " + devFirstName + " " + devLastName);
            System.out.println("Task Number: " + i);
            System.out.println("Task Name: " + taskName);
            System.out.println("Task Description: " + taskDescription);
            System.out.println("Task ID: " + taskID);
            System.out.println("Task Duration: " + taskDuration + " hours");

            int totalTaskDuration = taskDuration;
        }
        String totalTaskDuration = null;

        System.out.println("\nTotal Task Duration: " + totalTaskDuration + " hours");
    }

    public String generateTaskID(String taskName, int taskNumber, String devLastName) {
        String taskID = taskName.substring(0, 2).toUpperCase() + ":" + taskNumber + ":" + devLastName.substring(devLastName.length() - 3).toUpperCase();
        return taskID;
    
    }
    public boolean checkUserName(){
        String regex="[\\w]{1,5}_[\\w]+$";
        Pattern pattern= Pattern.compile(regex);
        Matcher matcher=pattern.matcher(username);
        return matcher.matches();
    }
    public boolean checkPasswordComplexity(){
        String regex= "^(?=.*[A-Z])(?=.[0-9])(?=.*[^A-Za-z0-9])(?=\\S+$";
        Pattern pattern= Pattern.compile(regex);
        Matcher matcher= pattern.matcher(password);
        return matcher.matches();
    }
    public String registerUser(){
        if(!checkUserName()){
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.";
        }
        if (!checkPasswordComplexity()){
            return "Password is not correctly formatted, please ensure the password contains at least 8 characters, a capital letter ,a number and a special character,";
        }
        return "Registration successful";
    }
    public String returnLoginStatus(boolean loginSuccess){
        if(loginSuccess){
            return "Welcome "+ firstName+" "+lastName +"it is great to see you again.";
        }else{
            return "Username or password incorrect, please try again.";
        }
    
    

}
    public class Task {
    private String taskName;
    private String taskDescription;
    private String developerDetails;
    private int taskDuration;
    private String taskID;
    private String taskStatus;

    public Task(String taskName, String taskDescription, String developerDetails, int taskDuration, String taskID, String taskStatus) {
        this.taskName = taskName;
        this.taskDescription = taskDescription;
        this.developerDetails = developerDetails;
        this.taskDuration = taskDuration;
        this.taskID = taskID;
        this.taskStatus = taskStatus;
    }

    public boolean checkTaskDescription() {
        return taskDescription.length() <= 50;
    }
//Java String Class - Oracle (https://docs.oracle.com/en/java/javase/11/docs/api/java.base/java/lang/String.html)
    public String createTaskID() {
        String[] devName = developerDetails.split(" ");
        String devLastName = devName[devName.length - 1];
        String[] devLastNameParts = devLastName.split("-");
        String devLastNameAbbreviation = devLastNameParts[devLastNameParts.length - 1].toUpperCase();
        return taskName.substring(0, 2).toUpperCase() + ":" + taskID + ":" + devLastNameAbbreviation;
    }

    public String printTaskDetails() {
        StringBuilder details = new StringBuilder();
        details.append("Task Details:\n");
        details.append("Task Status: ").append(taskStatus).append("\n");
        details.append("Developer Details: ").append(developerDetails).append("\n");
        details.append("Task Number: ").append(taskID).append("\n");
        details.append("Task Name: ").append(taskName).append("\n");
        details.append("Task Description: ").append(taskDescription).append("\n");
        details.append("Task ID: ").append(taskID).append("\n");
        details.append("Task Duration: ").append(taskDuration).append(" hours\n");
        return details.toString();
    }

    public int returnTotalHours(List<Task> tasks) {
        int totalHours = 0;
        for (Task task : tasks) {
            totalHours += task.taskDuration;
        }
        return totalHours;
    }
}
public class TaskTest {

    @Test
    public void testCheckTaskDescription_Success() {
        Task task = new Task("Login Feature", "Create Login to authenticate users",
                "Robyn Harrison", 8, "AD:1:BYN", "To Do");
        Assertions.assertTrue(task.checkTaskDescription());
    }

    @Test
    public void testCheckTaskDescription_Failure() {
        Task task = new Task("Login Feature", "Create Login to authenticate users and validate credentials" +
                " with the database to ensure security measures are in place",
                "Robyn Harrison", 8, "AD:1:BYN", "To Do");
        Assertions.assertFalse(task.checkTaskDescription());
    }

    @Test
    public void testCreateTaskID() {
        Task task = new Task("Login Feature", "Create Login to authenticate users",
                "Robyn Harrison", 8, "AD:1:BYN", "To Do");
        Assertions.assertEquals("AD:1:BYN", task.createTaskID());
    }

    @Test
    public void testPrintTaskDetails() {
        Task task = new Task("Login Feature", "Create Login to authenticate users",
                "Robyn Harrison", 8, "AD:1:BYN", "To Do");

        String expectedDetails = "Task Details:\n" +
                "Task Status: To Do\n" +
                "Developer Details: Robyn Harrison\n" +
                "Task Number: AD:1:BYN\n" +
                "Task Name: Login Feature\n" +
                "Task Description: Create Login to authenticate users\n" +
                "Task ID: AD:1:BYN\n" +
                "Task Duration: 8 hours\n";

        Assertions.assertEquals(expectedDetails, task.printTaskDetails());
    }

    @Test
    public void testReturnTotalHours() {
        List<Task> tasks = new ArrayList<>();
        tasks.add(new Task("Task 1", "Description 1", "Developer 1", 10, "AD:1:DEV1", "To Do"));
        tasks.add(new Task("Task 2", "Description 2", "Developer 2", 12, "AD:2:DEV2", "To Do"));
        tasks.add(new Task("Task 3", "Description 3", "Developer 3", 55, "AD:3:DEV3", "To Do"));
        tasks.add(new Task("Task 4", "Description 4", "Developer 4", 11, "AD:4:DEV4", "To Do"));
        tasks.add(new Task("Task 5", "Description 5", "Developer 5", 1, "AD:5:DEV5", "To Do"));
//ArrayList Documentation - Oracle (https://docs.oracle.com/en/java/javase/11/docs/api/java.base/java/util/ArrayList.html)
        int expectedTotalHours = 10 + 12 + 55 + 11 + 1;
        ;
    }
}
class LoginTest {
//JUnit 5 Documentation - JUnit Team (https://junit.org/junit5/docs/current/user-guide/)
    // Test for a correctly formatted username
    
    public void testCorrectUsernameFormat() {
        Login login = new Login("kyl_1", "Ch&&sec@ke99!", "Kyle", "Lastname");
        assertTrue(login.checkUserName());
    }

    // Test for an incorrectly formatted username
    
    public void testIncorrectUsernameFormat() {
        Login login = new Login("kyle!!!!!!!", "Ch&&sec@ke99!", "Kyle", "Lastname");
        assertFalse(login.checkUserName());
    }

    // Test for a password that meets the complexity requirements
    
    public void testComplexPassword() {
        Login login = new Login("kyl_1", "Ch&&sec@ke99!", "Kyle", "Lastname");
        assertTrue(login.checkPasswordComplexity());
    }

    // Test for a password that does not meet the complexity requirements
    
    public void testSimplePassword() {
        Login login = new Login("kyl_1", "password", "Kyle", "Lastname");
        assertFalse(login.checkPasswordComplexity());
    }

    // Test for a successful login
    
    public void testSuccessfulLogin() {
        Login login = new Login("example_username", "Example1!", "Kyle", "Lastname");
        assertTrue(login.loginUser());
    }

    // Test for a failed login
    
    public void testFailedLogin() {
        Login login = new Login("wrong_username", "wrong_password", "Kyle", "Lastname");
        assertFalse(login.loginUser());
    }

        private void assertTrue(boolean checkUserName) {
            throw new UnsupportedOperationException("Not supported yet."); 
        }

        private void assertFalse(boolean checkUserName) {
            throw new UnsupportedOperationException("Not supported yet."); 
        }
    }
}
